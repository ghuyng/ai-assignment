# This is a solution to Path Finding problem using A\* algorithm

# Prerequisites: install pygame
` pip install pygame`

# To run the program:
` python3 pathfinding.py`

#### After the window appears:
Use left mouse click to choose the start point (orange) and end point (blue)    
After choosing the start and end point, use left mouse button to set up barriers  
Use right mouse button to reset a square  
Press 'c' to reset the board  
Press 'space' to start the path-finding algorithm  
